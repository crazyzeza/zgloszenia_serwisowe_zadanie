import React, { useEffect, useState } from "react";
import Header from "./components/Header";
import Filter from "./components/Filter";
import ZgloszeniaList from "./components/ZgloszeniaList";
import AddZgloszenieForm from "./components/AddZgloszenieForm";
import Summary from "./components/Summary";
import "./App.css";

function App() {
  const [zgloszenia, setZgloszenia] = useState([]);
  const [filter, setFilter] = useState("wszystkie");

  useEffect(() => {
    fetch("/zgloszenia.json")
      .then(res => res.json())
      .then(data => setZgloszenia(data));
  }, []);

  const addZgloszenie = (nowe) => {
    setZgloszenia([...zgloszenia, nowe]);
  };

  const filtered = filter === "wszystkie"
    ? zgloszenia
    : zgloszenia.filter(z => z.status === filter);

  return (
    <div className="container">
      <Header />
      <Summary zgloszenia={zgloszenia} />
      <Filter setFilter={setFilter} />
      <AddZgloszenieForm addZgloszenie={addZgloszenie} />
      <ZgloszeniaList zgloszenia={filtered} />
    </div>
  );
}

export default App;